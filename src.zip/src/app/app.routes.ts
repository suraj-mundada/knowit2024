import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { LayoutComponent } from './pages/layout/layout.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { PostComponent } from './pages/post/post.component';
import { AlbumComponent } from './pages/album/album.component';
import { TodoComponent } from './pages/todo/todo.component';
import { CommentComponent } from './pages/comment/comment.component';
import { PhotoComponent } from './pages/photo/photo.component';

export const routes: Routes = [
    {
        path:'',
        redirectTo:'login',
        pathMatch:'full'
    },
    {
        path:'login',
        component: LoginComponent
    },
    {
        path:'layout/:id',
        component: LayoutComponent
    },
    {
        path:'',
        component: LayoutComponent,
        children:[
            {
                path:'dashboard/:id',
                component:DashboardComponent
            },
            {
                path:'post/:id',
                component:PostComponent,
                children:[
                    {
                        path:'comment',
                        component:CommentComponent
                    }

                ]
            },
            {
                path:'album/:id',
                component:AlbumComponent,
                children:[
                    {
                        path:'photo/:id',
                        component:PhotoComponent
                    }

                ]
            },
            {
                path:'todo/:id',
                component:TodoComponent
            }
            
           
        ]
    }
    
];


