import { routes } from './../../app.routes';
import { Component, EventEmitter, Output } from '@angular/core';
import { MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatSidenavModule} from '@angular/material/sidenav'
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { RouterLink } from '@angular/router';
import { RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { OnInit } from '@angular/core';
import { DashboardComponent } from "../dashboard/dashboard.component";
import { LocalStorageComponent } from '../../shared/local-storage/local-storage.component';





@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [MatSidenavModule, MatToolbarModule, MatButtonModule, MatIconModule, RouterOutlet, RouterLink, RouterLinkActive, CommonModule, DashboardComponent],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.scss'
})
export class LayoutComponent implements OnInit {

   userId :string |null=null;
   constructor(private route: ActivatedRoute,private localService:LocalStorageComponent){
    
  }
  
  
  stroage : any;
  ngOnInit(): void {
    //this.userId=this.route.snapshot.paramMap.get('id');
    this.stroage=this.localService.getItem('user')
    console.log("Obj"+this.stroage);

    this.route.paramMap.subscribe(params => {
     
      this.userId = params.get('id');
      this.stroage=this.localService.getItem('user')
      this.userId=this.stroage.id;
      console.log("stroge"+this.userId);
    })
  }
  fetchUserData(id: string): void{

  }
  getChildValue(event:string){
    console.log("event"+event);
     this.userId=event;
  }

}