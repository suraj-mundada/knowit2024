import { HttpClient } from '@angular/common/http';
import { Component,OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { baseUrl } from '../../shared/globalContants';
import {MatCardModule} from '@angular/material/card';
import { CommonModule } from '@angular/common';
import {MatListModule} from '@angular/material/list';
import { MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {  Router } from '@angular/router';


@Component({
  selector: 'app-album',
  standalone: true,
  imports: [MatCardModule,CommonModule,MatListModule,MatIconModule,MatButtonModule,MatToolbarModule],
  templateUrl: './album.component.html',
  styleUrl: './album.component.scss'
})
export class AlbumComponent implements OnInit {
  userId :string |null=null;
  constructor(private route: ActivatedRoute,private http:HttpClient,private router:Router){
   
 }

 ngOnInit(): void {
   //this.userId=this.route.snapshot.paramMap.get('id');
   this.route.paramMap.subscribe(params => {
     this.userId = params.get('id');
     console.log(this.userId);
     if(this.userId){
        this.fetchUserAlbum(this.userId);
     }
   })
 }
  albums:any;
 fetchUserAlbum(id:string):void{
  this.http.get(`${baseUrl}/users/${this.userId}/albums`).subscribe(
    (response: any) => {
      this.albums = response;
      console.log(this.albums);
    },
    (error) => {
      console.error('Error fetching data', error);
    }
  );


 }

 onAlbumClick(album: any) {
  console.log("photo : "+album.id);
  this.router.navigate(['/photo',album.id]);
}

}
