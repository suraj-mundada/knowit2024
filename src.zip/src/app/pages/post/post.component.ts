import { HttpClient } from '@angular/common/http';
import { Component,OnInit } from '@angular/core';
import {MatCardModule} from '@angular/material/card';
import { ActivatedRoute } from '@angular/router';
import { baseUrl } from '../../shared/globalContants';
import { CommonModule } from '@angular/common';
import { MatButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';


@Component({
  selector: 'app-post',
  standalone: true,
  imports: [MatIcon ,MatCardModule, CommonModule,MatButton],
  templateUrl: './post.component.html',
  styleUrl: './post.component.scss'
})
export class PostComponent implements OnInit {
  userId :string |null=null;
  constructor(private route: ActivatedRoute,private http:HttpClient){
   
 }

 ngOnInit(): void {
   //this.userId=this.route.snapshot.paramMap.get('id');
   this.route.paramMap.subscribe(params => {
     this.userId = params.get('id');
     console.log(this.userId);
     if(this.userId){
      this.fetchUserData(this.userId);
     }
   })
 }

 posts :any;
 fetchUserData(id: string):void{
  this.http.get(`${baseUrl}/users/${this.userId}/posts`).subscribe(
    (response: any) => {
      this.posts = response;
      console.log(this.posts);
    },
    (error) => {
      console.error('Error fetching data', error);
    }
  );
 }
}
