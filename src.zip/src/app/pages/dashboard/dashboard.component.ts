import { Component, OnInit ,EventEmitter,Output} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TodoComponent } from "../todo/todo.component";



@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [TodoComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent implements OnInit {
 
  public userId :string |null=null;
  constructor(private route: ActivatedRoute){
    
  }

  ngOnInit(): void {
    //this.userId=this.route.snapshot.paramMap.get('id');
    this.route.paramMap.subscribe(params => {
      this.userId = params.get('id');
      console.log(this.userId);
      // if(this.userId){
      //   this.sendToParent();
      // }
    })
  }

  @Output() sendValue = new EventEmitter<string>()
  sendToParent(){
    if (this.userId) {
      console.log("hii");
      this.sendValue.emit(this.userId);
    }
  }
}