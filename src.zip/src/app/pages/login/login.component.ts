
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ReactiveFormsModule , FormControl, FormBuilder, Validators, FormGroup} from '@angular/forms'
import {MatFormFieldModule} from '@angular/material/form-field'
import {MatInputModule} from '@angular/material/input'
import {MatButtonModule} from '@angular/material/button'
import {MatCardModule} from '@angular/material/card'
import { baseUrl } from '../../shared/globalContants';
import { HttpClient } from '@angular/common/http';
import {  Router } from '@angular/router';
import { LocalStorageComponent } from '../../shared/local-storage/local-storage.component';


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, MatFormFieldModule,MatInputModule,MatButtonModule,MatCardModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {

  

  
  loginForm: FormGroup= new FormGroup({
    email: new FormControl('',[Validators.required, Validators.email]),
    password: new FormControl('',[Validators.required,Validators.minLength(6)])

  });
  
  constructor( private http: HttpClient, private router: Router ,private localService: LocalStorageComponent){
      this.getUser();
   }
   public data:any
   masterPassword :string= "123456";

   getUser(){
    this.http.get(`${baseUrl}/users`).subscribe((data:any)=> {this.data=data});
   }

  onSubmit(){
    if(this.loginForm.valid){
      let id;
       const fromValues = this.loginForm.value;
       console.log(fromValues);
       
       let flag=false;
       
       if(this.data && Array.isArray(this.data)){
         if(this.masterPassword===fromValues.password){
         
          let validUser=this.data.filter((m)=>m.email===fromValues.email)
          console.log(validUser);
          if(validUser.length==1){
            flag=true;

            this.localService.setItem('user',validUser[0]);

            id=validUser[0].id;
          }
         }
       }

       if(flag){
        alert("Login Succeful")
        this.router.navigate(['/layout',id]);
       }else{
        alert("Wrong Cradentials")
        this.router.navigate(['login']);
       }
      }
  this.loginForm.reset();
}

  onReset(){
    this.loginForm.reset();
  }

}

