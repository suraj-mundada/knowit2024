import { Component ,OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-todo',
  standalone: true,
  imports: [],
  templateUrl: './todo.component.html',
  styleUrl: './todo.component.scss'
})
export class TodoComponent implements OnInit {
  userId :string |null=null;
  constructor(private route: ActivatedRoute){
   
 }

 ngOnInit(): void {
   //this.userId=this.route.snapshot.paramMap.get('id');
   this.route.paramMap.subscribe(params => {
     this.userId = params.get('id');
     console.log(this.userId);
   })
 }
}
